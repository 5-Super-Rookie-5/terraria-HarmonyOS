use napi_derive_ohos::napi;
use std::thread;
use std::net::SocketAddr;
use std::path::PathBuf;
use std::panic;
use tokio::runtime::Runtime;
use tokio::fs;
use axum::{
    body::Body,
    extract::{Path},
    http::{StatusCode, header},
    response::{IntoResponse, Response},
    routing::get,
    Router,
};
use mime_guess; 
use ohos_hilog_binding::{hilog_info, hilog_error};

const BASE_PATH: &str = "/data/storage/el1/bundle/entry/resources/resfile/";

#[napi]
pub fn server(port: u32) {
    hilog_info!("NAPI: Server start request received for port {}", port);

    thread::spawn(move || {
        panic::set_hook(Box::new(|info| {
            let msg = match info.payload().downcast_ref::<&'static str>() {
                Some(s) => *s,
                None => match info.payload().downcast_ref::<String>() {
                    Some(s) => &s[..],
                    None => "Box<Any>",
                },
            };
            let location = info.location().map(|l| format!("{}:{}", l.file(), l.line())).unwrap_or("unknown".to_string());
            hilog_error!("NAPI PANIC: '{}' at {}", msg, location);
        }));

        let rt = match Runtime::new() {
            Ok(r) => r,
            Err(e) => {
                hilog_error!("NAPI: Failed to create Tokio runtime: {}", e);
                return;
            }
        };

        rt.block_on(async move {
            let app = Router::new()
                .route("/", get(serve_index))
                .route("/*path", get(serve_static_file));
            let addr_str = format!("127.0.0.1:{}", port);
            let addr: SocketAddr = match addr_str.parse() {
                Ok(a) => a,
                Err(e) => {
                    hilog_error!("NAPI: Failed to parse address '{}': {}", addr_str, e);
                    return;
                }
            };

            hilog_info!("NAPI: Server starting on http://{}", addr);

            let listener = match tokio::net::TcpListener::bind(addr).await {
                Ok(l) => l,
                Err(e) => {
                    hilog_error!("NAPI: Failed to bind port {}: {}", port, e);
                    return;
                }
            };

            if let Err(e) = axum::serve(listener, app).await {
                hilog_error!("NAPI: Server runtime error: {}", e);
            }
        });
    });
}

async fn serve_index() -> impl IntoResponse {
    let path = PathBuf::from(BASE_PATH).join("index.html");
    read_file_and_add_headers(path).await
}

async fn serve_static_file(Path(path_str): Path<String>) -> impl IntoResponse {
    if path_str.contains("..") {
        return (StatusCode::FORBIDDEN, "Access Denied").into_response();
    }
    let path = PathBuf::from(BASE_PATH).join(path_str);
    read_file_and_add_headers(path).await
}

async fn read_file_and_add_headers(path: PathBuf) -> Response {
    match fs::read(&path).await {
        Ok(content) => {
            let mime_type = mime_guess::from_path(&path).first_or_octet_stream();
            Response::builder()
                .status(StatusCode::OK)
                .header("Cross-Origin-Embedder-Policy", "require-corp")
                .header("Cross-Origin-Opener-Policy", "same-origin")
                .header(header::CONTENT_TYPE, mime_type.as_ref())
                .body(Body::from(content))
                .unwrap()
        }
        Err(e) => {
            hilog_error!("NAPI: File not found {:?}: {}", path, e);
            (StatusCode::NOT_FOUND, "Not Found").into_response()
        }
    }
}
