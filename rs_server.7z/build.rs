fn main() {
  napi_build_ohos::setup();
}
